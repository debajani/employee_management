<?php
class Blogmodel extends CI_Model 
{

    
	function show()
	{
		echo "this is the model";
		$id='a';
		//$result=$this->db->query("select email_id from Employee");
		//print_r($result);
		//echo $this->db->result($result);
		$this->db->select('email_id, gender');

		$query = $this->db->get('Employee');

		foreach ($query->result() as $row)
		{
			echo $row->email_id;
		}
	}
   
	
}
?>