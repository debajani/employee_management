<?php
class Blog1 extends CI_Controller {

       public function __construct()
       {
            parent::__construct();
            echo "you are in constructor";
       }
}
?>